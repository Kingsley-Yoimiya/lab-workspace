#!/usr/bin/env bash
set -uo pipefail
export TP=1 PP=4 EP=4 ETP=1 MBS=1 GBS=2048 SEQ_LENGTH=4096
export SKIP_TB=1 SKIP_SAVE=1 SKIP_PROFILE=1 TRAIN_ITERS=8
export PROBING=0 PROBING_HOME=/afs-a3-241ceshi-shared/montyyin/lab-workspace/projects/Probing_plus
export PATH=/root/miniconda3/envs/llm_test/bin:$PATH
export PYTHONPATH=/MindSpeed-LLM/MindSpeed:${PYTHONPATH:-}
export WORLD_SIZE=2 NNODES=2 RANK=1 NODE_RANK=1
export MASTER_ADDR=montyyin-moe-scale-96-master-0.montyyin-moe-scale-96 MASTER_PORT=25400
export NPUS_PER_NODE=16 GPUS_PER_NODE=16
export DATA_ROOT=/afs-a3-241ceshi-shared/geruijun RUN_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32 LOG_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32/
export TENSORBOARD_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32/tb CKPT_SAVE_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32/ckpt
export HCCL_IF_BASE_PORT=$((MASTER_PORT+2000))
if [[ "$PROBING" != "0" ]]; then
  [[ -f /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh ]] && source /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh || true
  export PYTHONPATH=$PROBING_HOME:$PROBING_HOME/python:$PYTHONPATH
fi
mkdir -p "$RUN_DIR" "$LOG_DIR" "$TENSORBOARD_DIR" "$CKPT_SAVE_DIR"
cd /afs-a3-241ceshi-shared/geruijun/Megatron-LM-0.12.3
bash /afs-a3-241ceshi-shared/montyyin/lab-workspace/scripts/cluster/wrappers/train_qwen3_30B_A3B_ascend.sh 2>&1 | tee /afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32/rank1.log
rc=${PIPESTATUS[0]}
echo TRAIN_RANK_1_DONE rc=$rc | tee -a /afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_181247/scale_32/rank1.log
exit $rc
