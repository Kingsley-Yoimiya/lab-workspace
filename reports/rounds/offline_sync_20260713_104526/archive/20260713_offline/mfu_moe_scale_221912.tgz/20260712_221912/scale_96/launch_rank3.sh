#!/usr/bin/env bash
set -uo pipefail
export TP=1 PP=4 EP=4 ETP=1 MBS=1 GBS=1920 SEQ_LENGTH=4096
export SKIP_TB=1 SKIP_SAVE=1 SKIP_PROFILE=1 TRAIN_ITERS=8
export PROBING=0 PROBING_HOME=/afs-a3-241ceshi-shared/montyyin/lab-workspace/projects/Probing_plus
export PATH=/root/miniconda3/envs/llm_test/bin:$PATH
export PYTHONPATH=/MindSpeed-LLM/MindSpeed:${PYTHONPATH:-}
export WORLD_SIZE=6 NNODES=6 RANK=3 NODE_RANK=3
export MASTER_ADDR=montyyin-moe96-r2-master-0.montyyin-moe96-r2 MASTER_PORT=25500
export NPUS_PER_NODE=16 GPUS_PER_NODE=16
export DATA_ROOT=/afs-a3-241ceshi-shared/geruijun RUN_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96 LOG_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96/
export TENSORBOARD_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96/tb CKPT_SAVE_DIR=/afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96/ckpt
export HCCL_IF_BASE_PORT=27500
export HCCL_EXEC_TIMEOUT=${HCCL_EXEC_TIMEOUT:-3600}
export HCCL_CONNECT_TIMEOUT=${HCCL_CONNECT_TIMEOUT:-3600}
if [[ "$PROBING" != "0" ]]; then
  [[ -f /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh ]] && source /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh || true
  export PYTHONPATH=$PROBING_HOME:$PROBING_HOME/python:$PYTHONPATH
fi
mkdir -p "$RUN_DIR" "$LOG_DIR" "$TENSORBOARD_DIR" "$CKPT_SAVE_DIR"
cd /afs-a3-241ceshi-shared/geruijun/Megatron-LM-0.12.3
bash /afs-a3-241ceshi-shared/montyyin/lab-workspace/scripts/cluster/wrappers/train_qwen3_30B_A3B_ascend.sh 2>&1 | tee /afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96/rank3.log
rc=${PIPESTATUS[0]}
echo TRAIN_RANK_3_DONE rc=$rc | tee -a /afs-a3-241ceshi-shared/montyyin/results/mfu_moe_scale/20260712_221912/scale_96/rank3.log
exit $rc
