#!/usr/bin/env bash
set -uo pipefail
export TP=4 PP=2 EP=1 ETP=1 MBS=1 GBS=1920 SEQ_LENGTH=4096
export SKIP_TB=1 SKIP_SAVE=1 SKIP_PROFILE=1 TRAIN_ITERS=80
export PROBING=1 PROBING_HOME=/afs-a3-241ceshi-shared/montyyin/lab-workspace/projects/Probing_plus FAILSLOW_STEP_LOG=1
export PATH=/root/miniconda3/envs/llm_test/bin:$PATH
export PYTHONPATH=/afs-a3-241ceshi-shared/montyyin/lab-workspace/scripts/cluster/hooks:/MindSpeed-LLM/MindSpeed:${PYTHONPATH:-}
export WORLD_SIZE=6 NNODES=6 RANK=4 NODE_RANK=4
export MASTER_ADDR=montyyin-moe96-r2-master-0.montyyin-moe96-r2 MASTER_PORT=26104
export NPUS_PER_NODE=16 GPUS_PER_NODE=16
export DATA_ROOT=/afs-a3-241ceshi-shared/geruijun RUN_DIR=/afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96 LOG_DIR=/afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/
export TENSORBOARD_DIR=/afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/tb CKPT_SAVE_DIR=/afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/ckpt
export HCCL_IF_BASE_PORT=28104
export HCCL_EXEC_TIMEOUT=${HCCL_EXEC_TIMEOUT:-3600}
export HCCL_CONNECT_TIMEOUT=${HCCL_CONNECT_TIMEOUT:-3600}
if [[ "$PROBING" != "0" ]]; then
  [[ -f /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh ]] && source /afs-a3-241ceshi-shared/montyyin/toolchains/rust-env.sh || true
  export PYTHONPATH=$PROBING_HOME:$PROBING_HOME/python:$PYTHONPATH
fi
mkdir -p "$RUN_DIR" "$LOG_DIR" "$TENSORBOARD_DIR" "$CKPT_SAVE_DIR"
# 强制挂接每卡 step timer（.pth 才会在 torchrun 子进程生效）
SP=$(python3 -c 'import site; print(site.getsitepackages()[0])' 2>/dev/null || true)
if [[ -n "$SP" && -d "$SP" ]]; then
  printf '%s\nimport failslow_step_timer\n' "/afs-a3-241ceshi-shared/montyyin/lab-workspace/scripts/cluster/hooks" > "$SP/zz_failslow_step.pth"
fi
cd /afs-a3-241ceshi-shared/geruijun/Megatron-LM-0.12.3
bash /afs-a3-241ceshi-shared/montyyin/lab-workspace/scripts/cluster/wrappers/train_qwen3_8B_ascend.sh 2>&1 | tee /afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/rank4.log
rc=${PIPESTATUS[0]}
echo TRAIN_RANK_4_DONE rc=$rc | tee -a /afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/rank4.log
# 汇总本节点 step_times 文件数
ls /afs-a3-241ceshi-shared/montyyin/results/dense_failslow_gbsprop/20260713_071316/scale_96/step_times_rank*.jsonl 2>/dev/null | wc -l | xargs -I{} echo STEP_FILES_NODE_4={}
exit $rc
